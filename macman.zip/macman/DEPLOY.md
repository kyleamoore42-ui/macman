# 🍕 Macman — Deployment Guide

## What you have
A fully working macro tracking PWA. Once deployed, open it in Safari on your iPhone and add it to your home screen — it'll look and work like a native app.

---

## Step 1 — Install Node.js (one-time, ~5 min)

1. Go to **https://nodejs.org**
2. Click the big green **"LTS"** download button
3. Open the downloaded file and follow the installer (just click Next/Continue through everything)
4. When done, open **Terminal** (Mac) or **Command Prompt** (Windows) and type:
   ```
   node --version
   ```
   You should see something like `v20.11.0`. That means it worked.

---

## Step 2 — Set up the project (one-time, ~3 min)

1. Unzip the `macman.zip` file you downloaded
2. Open **Terminal** (Mac) or **Command Prompt** (Windows)
3. Type `cd ` (with a space after), then drag the `macman` folder into the terminal window — it'll auto-fill the path. Hit Enter.
4. Now type:
   ```
   npm install
   ```
   Wait for it to finish (may take 1–2 min, lots of text is normal).
5. Then type:
   ```
   npm run build
   ```
   This creates a `dist` folder — that's your app, ready to deploy.

---

## Step 3 — Deploy to Vercel (one-time, ~5 min)

1. Go to **https://vercel.com** and click **Sign Up** — use your GitHub or Google account (free)
2. Once logged in, click **"Add New Project"**
3. Click **"Upload"** (you don't need GitHub for this)
4. Drag your entire `macman` folder onto the upload area  
   *(or click to browse and select the folder)*
5. Vercel will auto-detect it's a Vite project. Just click **Deploy**
6. Wait ~60 seconds. You'll get a URL like `https://macman-abc123.vercel.app` 🎉

---

## Step 4 — Install on your iPhone

1. Open **Safari** on your iPhone (must be Safari, not Chrome)
2. Go to your Vercel URL (e.g. `https://macman-abc123.vercel.app`)
3. Tap the **Share button** (the box with an arrow pointing up, at the bottom of Safari)
4. Scroll down and tap **"Add to Home Screen"**
5. Tap **"Add"** in the top right
6. **Done!** Macman is now on your home screen 🎉

---

## Pushing updates in the future

Whenever we make changes to the app:

1. Run `npm run build` again in Terminal (from the macman folder)
2. Go to your project on **vercel.com**
3. Click **"Deployments"** → **"Redeploy"** and upload the new `dist` folder
   — OR —
   Drag the updated `macman` folder onto Vercel again

Your phone gets the update automatically next time it opens the app. No re-installing needed.

---

## Your data

- Food logs save automatically to your phone's browser storage
- Data resets each day (today's log is today's log)
- Food search pulls from **Open Food Facts** — a free database with 3M+ products worldwide
- Works offline for everything except food search (which needs internet)

---

## Need help?

If anything goes wrong at any step, just paste the error message into your Claude chat and we'll fix it together.
